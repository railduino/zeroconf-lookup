/*
 * Generated file - do not edit; run ./configure
 */

#ifndef _CONFIG_H
#define _CONFIG_H 1

#define CONFIG_FILE	"/etc/zeroconf_lookup.conf"

#define GOOGLE_TAG	"gikfkgfjepbdpiljbieedpkcjikapbbg"
#define MOZILLA_TAG	"zeroconf_lookup@railduino.com"
#define TIME_OUT	"1"
#define FORCE_METHOD	""

#endif /* !_CONFIG_H */

